const Footer=()=>{
  return (
    <div className="text-center text-xs text-gray-400 py-4">
      © 2026 VaultPay · Banking-grade security
    </div>
  );
}

export default Footer;