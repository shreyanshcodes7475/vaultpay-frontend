import { useState } from "react";
import axios from "axios";
import Base_url from "../Constants/Base_url";

const Wallet=()=>{
  const [pin, setPin] = useState("");
  const [balance, setBalance] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const checkBalance = async () => {
    if (pin.length !== 6) {
      return setError("Enter 6 digit wallet PIN");
    }

    try {
      setLoading(true);
      setError("");

      const res = await axios.post(
        Base_url + "/wallet/balance",
        { walletPin: pin },
        { withCredentials: true }
      );
      setBalance(res.data.balance);
    } catch (err) {
      setError(err.response?.data?.message || "Verification failed");
    } finally {
      setLoading(false);
    }
  };


     return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f172a] to-[#020617] flex items-center justify-center px-6">

      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-10 space-y-6">

        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-900">Check Wallet Balance</h2>
          <p className="text-slate-500 text-sm mt-1">Secure access required</p>
        </div>

        {balance === null ? (
          <>
            <input
              type="password"
              maxLength={6}
              placeholder="Enter 6 digit PIN"
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
              className="input input-bordered w-full text-center tracking-widest text-xl"
            />

            {error && <p className="text-red-500 text-sm text-center">{error}</p>}

            <button
              onClick={checkBalance}
              className="btn btn-primary w-full"
              disabled={loading}
            >
              {loading ? "Verifying..." : "Check Balance"}
            </button>
          </>
        ) : (
          <div className="text-center space-y-4">
            <p className="text-slate-500 text-sm">Available Balance</p>
            <h1 className="text-4xl font-bold text-blue-600">₹{balance}</h1>

            <button
              onClick={() => {
                setBalance(null);
                setPin("");
              }}
              className="btn btn-outline w-full"
            >
              Hide Balance
            </button>
          </div>
        )}
      </div>
    </div>
  );
    
}

export default Wallet;