const Base_url="http://localhost:5000/api"

export default Base_url;